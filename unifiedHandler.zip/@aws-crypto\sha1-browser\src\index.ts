export * from "./crossPlatformSha1";
export { Sha1 as WebCryptoSha1 } from "./webCryptoSha1";
